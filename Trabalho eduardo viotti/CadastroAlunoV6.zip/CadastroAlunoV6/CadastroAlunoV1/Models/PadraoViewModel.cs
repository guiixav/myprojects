﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CadastroAlunoV1.Models
{
    public abstract class PadraoViewModel
    {
        public virtual int Id { get; set; }
    }
}
